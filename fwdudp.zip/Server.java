import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import javax.swing.JOptionPane;

public class Server {

	public static void main(String[] args) throws IOException {
		DatagramSocket serverSocket = null;
		try {
			serverSocket = new DatagramSocket(9876);
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        while(true){
        		byte[] receiveData = new byte[1024];
            byte[] sendData = new byte[1024];
        		DatagramPacket receivePkt = new DatagramPacket(receiveData, receiveData.length);
        		serverSocket.receive(receivePkt);
        		String rsvMsg = new String(receivePkt.getData());
        		System.out.println("RECEIVED: " + rsvMsg);
        		InetAddress IPAddress = receivePkt.getAddress();
        		int port = receivePkt.getPort();
        		String sendMsg = processRequest(rsvMsg);
        		sendData = sendMsg.getBytes();
        		DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, port);
        		serverSocket.send(sendPacket);
        	}
	}

	private static String processRequest(String msg) {
		String[] parsed = msg.split(",");
		int mode = Integer.parseInt(parsed[0]);
		String ans = "Yolo";
		float p,r,t;
		double angle;
		try {
			switch (mode) {
			case 1:
				//Simple Intrest
				p = Float.parseFloat(parsed[1]);
				r = Float.parseFloat(parsed[2]);
				t = Float.parseFloat(parsed[3]);
				ans = String.valueOf(p*r*t);
				break;

			case 2:
				//Trig functions
				ans = trig(parsed);
				break;
			case 3:
				//vowels
				ans = countVowels(msg.substring(2), true);
				break;
			case 4:
				//consonents
				ans = countVowels(msg.substring(2), false);
				break;
			case 5:
				//calculator
				ans = calculator(msg.substring(2).trim());
				break;
			case 6:
				//len of str
				ans = String.valueOf(parsed[1].trim().length());
				break;
			case 7:
				//uppercase
				ans = parsed[1].toUpperCase();
				break;
			case 8:
				//lowercase
				ans = parsed[1].toLowerCase();
				break;
			case 9:
				//concat
				ans = parsed[1] + parsed[2];
				break;
			case 10:
				//compare
				if(parsed[1].equals(parsed[2])) {
					JOptionPane.showMessageDialog(null, "They are equal");
				}
				else {
					JOptionPane.showMessageDialog(null, "They are not equal");
				}
				break;
			case 11:
				//substring
				break;
			default:
				break;
			}
		}catch(Exception e){
			ans = "Invalid input";
		}
		return ans;
	}

	private static String calculator(String eqation) {
		// TODO Auto-generated method stub
		//System.out.println(eqation.length());
		ScriptEngineManager mgr = new ScriptEngineManager();
		ScriptEngine eg = mgr.getEngineByName("JavaScript");
		try {
			return ""+ eg.eval(eqation.trim());
		} catch (ScriptException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "Error";
	}

	private static String countVowels(String msg, boolean vowel) {
		// TODO Auto-generated method stub
		System.out.println(msg);
		String ans = "Oops";
		String vowels = "aeiou";
		HashMap<Character, Integer> letterCount = new HashMap<>();
		msg = msg.toLowerCase();
		int count = 0;
		for(int i=0; i<msg.length(); i++) {
			if(vowel && vowels.contains(String.valueOf(msg.charAt(i)))) {
				count++;
			}
			else if(!vowel && !vowels.contains(String.valueOf(msg.charAt(i)))) {
				count++;
			}
			if(letterCount.containsKey(msg.charAt(i))) {
				letterCount.replace(msg.charAt(i), letterCount.get(msg.charAt(i))+1);
			}else {
				letterCount.put(msg.charAt(i), 1);
			}
		}
		System.out.println(count);
		try {
		StringBuilder temp = new StringBuilder(" ");
        temp.append("Count: " + count + "\nFrequencies:\n");
		Iterator it = letterCount.entrySet().iterator();
	    while (it.hasNext()) {
	        Map.Entry pair = (Map.Entry)it.next();
	        if(vowel && vowels.contains(String.valueOf(pair.getKey()))) {
	        		temp.append(pair.getKey() + " = " + pair.getValue() + "\n");
	        }
	        else if(!vowel && !vowels.contains(String.valueOf(pair.getKey()))){
	        		temp.append(pair.getKey() + " = " + pair.getValue() + "\n");
	        }
	        it.remove(); // avoids a ConcurrentModificationException
	    }
	    System.out.println(ans);
		ans = temp.toString();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return ans;
	}

	private static String trig(String[] parsed) {
		String ans = null;
		double angle;
		if(parsed[1].split(" ")[0].equalsIgnoreCase("sin")) {
			angle = Double.parseDouble(parsed[1].split(" ")[1]);
			ans = String.valueOf(Math.sin(angle));
		}
		else if(parsed[1].split(" ")[0].equalsIgnoreCase("cos")) {
			angle = Double.parseDouble(parsed[1].split(" ")[1]);
			ans = String.valueOf(Math.cos(angle));
		}
		else if(parsed[1].split(" ")[0].equalsIgnoreCase("tan")) {
			angle = Double.parseDouble(parsed[1].split(" ")[1]);
			ans = String.valueOf(Math.tan(angle));
		}
		else
			ans ="Invalid input";
		return ans;
	}

}
