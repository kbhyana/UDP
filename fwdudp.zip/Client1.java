import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class Client1 extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JTextField textField;
	JRadioButton rdbtnSimIn = new JRadioButton("Simple Interest");
	JRadioButton rdbtnTri = new JRadioButton("Trigonometry");
	JButton btnOk = new JButton("OK");
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Client1 frame = new Client1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Client1(){
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		rdbtnSimIn.setSelected(true);
		
		
		rdbtnSimIn.setBounds(34, 35, 141, 23);
		contentPane.add(rdbtnSimIn);
		
		rdbtnTri.setBounds(34, 75, 141, 23);
		contentPane.add(rdbtnTri);
		
		//group buttons
		ButtonGroup btngrp = new ButtonGroup();
		btngrp.add(rdbtnSimIn);
		btngrp.add(rdbtnTri);
		
		textField = new JTextField();
		textField.setBounds(126, 136, 190, 26);
		contentPane.add(textField);
		textField.setColumns(10);
		
		btnOk.setBounds(169, 192, 117, 29);
		contentPane.add(btnOk);
		btnOk.addActionListener(this);
		
		JLabel lblParameters = new JLabel("Parameters:");
		lblParameters.setBounds(38, 141, 76, 16);
		contentPane.add(lblParameters);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		int mode = 0;
		if(rdbtnSimIn.isSelected()) {
			mode = 1;
		}
		if(rdbtnTri.isSelected()) {
			mode = 2;
		}
		sendReqToServer(mode + "," + textField.getText().toString());
	}

	private void sendReqToServer(String req){
		try {
			DatagramSocket clientSocket = new DatagramSocket();
			InetAddress IPAddress = InetAddress.getByName("localhost");
			byte[] sendData = new byte[1024];
			byte[] receiveData = new byte[1024];
			sendData = req.getBytes();
			DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, 9876);
			clientSocket.send(sendPacket);
			DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
			clientSocket.receive(receivePacket);
			String reviecedMsg = new String(receivePacket.getData());
			JOptionPane.showMessageDialog(null, reviecedMsg);
			clientSocket.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
}
