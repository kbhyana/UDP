import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.ButtonGroup;
import javax.swing.JButton;

public class Client2 extends JFrame implements ActionListener{

	private JPanel contentPane;
	private JTextField textField;
	JRadioButton rdbtnConsonents = new JRadioButton("Consonents");
	JRadioButton rdbtnVowels = new JRadioButton("Vowels");
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Client2 frame = new Client2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Client2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		rdbtnVowels.setSelected(true);
		rdbtnVowels.setBounds(31, 45, 141, 23);
		contentPane.add(rdbtnVowels);
		
		
		rdbtnConsonents.setBounds(31, 91, 141, 23);
		contentPane.add(rdbtnConsonents);
		
		ButtonGroup grp = new ButtonGroup();
		grp.add(rdbtnVowels);
		grp.add(rdbtnConsonents);
		
		textField = new JTextField();
		textField.setBounds(95, 146, 241, 26);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnOk = new JButton("OK");
		btnOk.setBounds(162, 184, 117, 29);
		contentPane.add(btnOk);
		
		btnOk.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		int mode = 0;
		if(rdbtnVowels.isSelected()) {
			mode = 3;
		}
		if(rdbtnConsonents.isSelected()) {
			mode = 4;
		}
		sendReqToServer(mode + "," + textField.getText().toString());

	}

	private void sendReqToServer(String req) {
		try {
			DatagramSocket clientSocket = new DatagramSocket();
			InetAddress IPAddress = InetAddress.getByName("localhost");
			byte[] sendData = new byte[1024];
			byte[] receiveData = new byte[1024];
			sendData = req.getBytes();
			DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, 9876);
			clientSocket.send(sendPacket);
			DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
			clientSocket.receive(receivePacket);
			String reviecedMsg = new String(receivePacket.getData());
			JOptionPane.showMessageDialog(null, reviecedMsg);
			clientSocket.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
	}
		
}
