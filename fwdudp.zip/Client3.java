import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.awt.event.ActionEvent;

public class Client3 extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Client3 frame = new Client3();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Client3() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setBounds(27, 34, 386, 16);
		contentPane.add(label);
		
		
		
		JButton btn1 = new JButton("1");
		btn1.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
				 label.setText(label.getText() + "1");
			}
		});
		btn1.setBounds(6, 159, 61, 29);
		contentPane.add(btn1);
		
		JButton btn2 = new JButton("2");
		btn2.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
				 label.setText(label.getText() + "2");
			}
		});
		btn2.setBounds(79, 159, 61, 29);
		contentPane.add(btn2);
		
		JButton btn3 = new JButton("3");
		btn3.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
				 label.setText(label.getText() + "3");
			}
		});
		btn3.setBounds(144, 159, 61, 29);
		contentPane.add(btn3);
		
		JButton btn4 = new JButton("4");
		btn4.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
				 label.setText(label.getText() + "4");
			}
		});
		btn4.setBounds(6, 118, 61, 29);
		contentPane.add(btn4);
		
		JButton btn5 = new JButton("5");
		btn5.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
				 label.setText(label.getText() + "5");
			}
		});
		btn5.setBounds(79, 118, 61, 29);
		contentPane.add(btn5);
		
		JButton btn6 = new JButton("6");
		btn6.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
				 label.setText(label.getText() + "6");
			}
		});
		btn6.setBounds(144, 118, 61, 29);
		contentPane.add(btn6);
		
		JButton btn7 = new JButton("7");
		btn7.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
				 label.setText(label.getText() + "7");
			}
		});
		btn7.setBounds(6, 77, 61, 29);
		contentPane.add(btn7);
		
		JButton btn8 = new JButton("8");
		btn8.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
				 label.setText(label.getText() + "8");
			}
		});
		btn8.setBounds(71, 77, 61, 29);
		contentPane.add(btn8);

		JButton btn9 = new JButton("9");
		btn9.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
				 label.setText(label.getText() + "9");
			}
		});
		btn9.setBounds(144, 77, 61, 29);
		contentPane.add(btn9);
		
		JButton btn0 = new JButton("0");
		btn0.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
				 label.setText(label.getText() + "0");
			}
		});
		btn0.setBounds(6, 200, 61, 29);
		contentPane.add(btn0);
		
		
		JButton clear = new JButton("C");
		clear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				label.setText("");
			}
		});
		clear.setBounds(144, 200, 61, 29);
		contentPane.add(clear);
		
		JButton plus = new JButton("+");
		plus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				label.setText(label.getText() + "+");
			}
		});
		plus.setBounds(217, 77, 61, 29);
		contentPane.add(plus);
		
		JButton minus = new JButton("-");
		minus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				label.setText(label.getText() + "-");
			}
		});
		minus.setBounds(217, 118, 61, 29);
		contentPane.add(minus);
		
		JButton mult = new JButton("*");
		mult.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				label.setText(label.getText() + "*");
			}
		});
		mult.setBounds(217, 159, 61, 29);
		contentPane.add(mult);
		
		JButton div = new JButton("/");
		div.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				label.setText(label.getText() + "/");
			}
		});
		div.setBounds(217, 200, 61, 29);
		contentPane.add(div);
		
		
		JButton btnSqrt = new JButton("sqrt(x)");
		btnSqrt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				label.setText( label.getText() + "Math.sqrt(" + JOptionPane.showInputDialog("Input base") + ")");
			}
		});
		btnSqrt.setBounds(290, 77, 78, 29);
		contentPane.add(btnSqrt);
		
		JButton btnCbrt = new JButton("x^(1/3)");
		btnCbrt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				label.setText( label.getText() + "Math.pow(" + JOptionPane.showInputDialog("Input base") + ", 1/3)");
			}
		});
		btnCbrt.setBounds(290, 118, 78, 29);
		contentPane.add(btnCbrt);
		
		JButton equal = new JButton("=");
		equal.setBounds(79, 200, 61, 29);
		contentPane.add(equal);
		
		JButton btnPow = new JButton("a^b");
		btnPow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				label.setText( label.getText() + "Math.pow(" + JOptionPane.showInputDialog("Input: base, exponent") + ")");
			}
		});
		btnPow.setBounds(290, 159, 78, 29);
		contentPane.add(btnPow);
		
		equal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sendReqToServer("5," + label.getText());
			}

		});
	}
	private void sendReqToServer(String req) {
		try {
			DatagramSocket clientSocket = new DatagramSocket();
			InetAddress IPAddress = InetAddress.getByName("localhost");
			byte[] sendData = new byte[1024];
			byte[] receiveData = new byte[1024];
			sendData = req.getBytes();
			DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, 9876);
			clientSocket.send(sendPacket);
			DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
			clientSocket.receive(receivePacket);
			String reviecedMsg = new String(receivePacket.getData());
			JOptionPane.showMessageDialog(null, reviecedMsg);
			clientSocket.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
	}
}
