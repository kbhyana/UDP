import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.ButtonGroup;
import javax.swing.JButton;

public class Client4 extends JFrame {

	private JPanel contentPane;
	private JTextField t1;
	private JTextField t2;
	int mode = 0;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Client4 frame = new Client4();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Client4() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		t1 = new JTextField();
		t1.setBounds(216, 15, 186, 26);
		contentPane.add(t1);
		t1.setColumns(10);
		
		JButton btnNewButton = new JButton("OK");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(t2.isVisible()) {
					sendReqToServer(mode + "," +t1.getText() + ", " + t2.getText());
				}
				else {
					sendReqToServer(mode + "," +t1.getText());
				}
				
			}
		});
		btnNewButton.setBounds(257, 184, 117, 29);
		contentPane.add(btnNewButton);
		
		t2 = new JTextField();
		t2.setColumns(10);
		t2.setBounds(216, 62, 186, 26);
		t2.setVisible(false);
		contentPane.add(t2);
		
		JRadioButton rdbtnLengthOfString = new JRadioButton("Length of String");
		rdbtnLengthOfString.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				t2.setVisible(false);
				mode = 6;
			}
		});
		rdbtnLengthOfString.setBounds(6, 16, 141, 23);
		contentPane.add(rdbtnLengthOfString);
		
		JRadioButton rdbtnToUppercase = new JRadioButton("To UpperCase");
		rdbtnToUppercase.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				t2.setVisible(false);
				mode = 7;
			}
		});
		rdbtnToUppercase.setBounds(6, 51, 141, 23);
		contentPane.add(rdbtnToUppercase);
		
		JRadioButton rdbtnToLowecase = new JRadioButton("To LoweCase");
		rdbtnToLowecase.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				t2.setVisible(false);
				mode = 8;
			}
		});
		rdbtnToLowecase.setBounds(6, 80, 141, 23);
		contentPane.add(rdbtnToLowecase);
		
		JRadioButton rdbtnConcatStrings = new JRadioButton("Concatinate 2 Strings");
		rdbtnConcatStrings.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				t2.setVisible(true);
				mode = 9;
			}
		});
		rdbtnConcatStrings.setBounds(6, 113, 167, 23);
		contentPane.add(rdbtnConcatStrings);
		
		JRadioButton rdbtnCompareStrings = new JRadioButton("Compare 2 Strings");
		rdbtnCompareStrings.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				t2.setVisible(true);
				mode = 10;
			}
		});
		rdbtnCompareStrings.setBounds(6, 150, 167, 23);
		contentPane.add(rdbtnCompareStrings);
		
		JRadioButton rdbtnFindSubstring = new JRadioButton("Find Substring");
		rdbtnFindSubstring.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				t2.setVisible(true);
			}
		});
		rdbtnFindSubstring.setBounds(6, 185, 167, 23);
		contentPane.add(rdbtnFindSubstring);
		
		ButtonGroup grp = new ButtonGroup();
		grp.add(rdbtnLengthOfString);
		grp.add(rdbtnToUppercase);
		grp.add(rdbtnToLowecase);
		grp.add(rdbtnConcatStrings);
		grp.add(rdbtnCompareStrings);
		grp.add(rdbtnFindSubstring);
	}
	
	private void sendReqToServer(String req) {
		try {
			DatagramSocket clientSocket = new DatagramSocket();
			InetAddress IPAddress = InetAddress.getByName("localhost");
			byte[] sendData = new byte[1024];
			byte[] receiveData = new byte[1024];
			sendData = req.getBytes();
			DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, 9876);
			clientSocket.send(sendPacket);
			DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
			clientSocket.receive(receivePacket);
			String reviecedMsg = new String(receivePacket.getData());
			JOptionPane.showMessageDialog(null, reviecedMsg);
			clientSocket.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
	}

}
